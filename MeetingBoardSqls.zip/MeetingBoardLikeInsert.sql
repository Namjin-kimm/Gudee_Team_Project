--------------------------------------------------------
--  ������ ������ - �ݿ���-10��-14-2022   
--------------------------------------------------------
REM INSERTING into HR.MEETINGLIKE_MEMBER
SET DEFINE OFF;
Insert into HR.MEETINGLIKE_MEMBER (MLMNUM,MEMBERNUM,MEETINGBOARDNUM) values (1,2,170);
Insert into HR.MEETINGLIKE_MEMBER (MLMNUM,MEMBERNUM,MEETINGBOARDNUM) values (21,2,169);
Insert into HR.MEETINGLIKE_MEMBER (MLMNUM,MEMBERNUM,MEETINGBOARDNUM) values (42,2,157);
